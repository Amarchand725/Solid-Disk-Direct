<?php

namespace App\Exports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;
use App\Http\Controllers\Api\ProductController;

class ProductsExport implements FromCollection, WithHeadings, WithMapping
{
    public function collection()
    {
        return Product::with(['hasBrand', 'hasProductCondition'])
            ->where('status', 1)
            ->whereNotNull('thumbnail')
            ->where('unit_price', '>=', 100)
            ->take(1)
            ->get();
    }

    public function headings(): array
    {
        // 'google_product_category',
        return [
            'ID', 'Title', 'Description', 'Link', 'Image Link', 'Availability', 'Price', 
            'Brand', 'MPN', 'Condition', 'Product Weight', 'Shipping Weight', 'Availability Date'
        ];
    }

    public function map($product): array
    {
        // $trail = [];

        // if ($product->mainCategory) {
        //     $trail = app(ProductController::class)
        //                 ->getCategoryTrailFromRelations($product->mainCategory);
        // }

        // $categoryPath = implode(' > ', array_column($trail, 'name'));

        return [
            $product->id ?? '-',
            $product->title ?? '-',
            strip_tags($product->short_description) ?? '-',
            url('/products/' . $product->slug) ?? '-',
            asset('storage/products/thumbnail/' . $product->thumbnail) ?? '-',
            'in stock',
            'USD ' . number_format($product->unit_price, 2) ?? '-',
            // $categoryPath,
            optional($product->hasBrand)->name ?? '-',
            $product->mpn ?? '-',
            optional($product->hasProductCondition)->name ?? '-',
            '5 lbs',
            '5 lbs',
            now()->addYear()->toIso8601String(),
        ];
    }

}
