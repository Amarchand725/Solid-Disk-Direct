<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CartResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            "session_id"  => $this->session_id ?? '',
            "status"  => $this->status ?? '',
            "subtotal"  => $this->subtotal ?? '',
            "discount_total"  => $this->discount_total ?? '',
            "shipping_cost"  => $this->shipping_cost ?? '',
            "total"  => $this->total ?? '',
            "items"  => $this->items ? CartItemResource::collection($this->items) : null ,
        ]; 
    }
}
