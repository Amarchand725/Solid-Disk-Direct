<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\CustomerResource;
use Exception;
use App\Models\Customer;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Notifications\SiteEventNotification;
use App\Traits\ApiResponse;

class CustomerController extends Controller
{
    use ApiResponse;

    protected $model;
    protected $modelResource;

    public function __construct(Customer $model)
    {
        $this->model = $model;
        $this->modelResource = new CustomerResource(null);
    }
    
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'name' => 'required|string|max:255',
            'email' => 'required|string|email|unique:customers,email',
            'phone' => 'required|max:20',
            'password' => 'required|string|min:6|confirmed',
            'countryId' => 'required',
            'i_have_read' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Something went wrong.'
            ], 422);
        } 
    
        DB::beginTransaction();
    
        try {
            $model = $this->model;
            $model->first_name = $request->first_name;
            $model->last_name = $request->last_name;
            $model->phone = $request->phone;
            $model->email = $request->email;
            $model->country_id = $request->countryId;
            $model->i_have_read = $request->i_have_read;
            $model->password = Hash::make($request->password);
    
            if ($model->save()) {
                DB::commit();
    
                // Optional: Notify admin
                if (function_exists('getActiveAdminUser')) {
                    $admin = getActiveAdminUser();
                    if (!empty($admin)) {
                        $url = route('customers.index');
                        $admin->notify(new SiteEventNotification(
                            'profile.png',
                            'New Registration',
                            "{$model->name} just registered.",
                            $url
                        ));
                    }
                }

                return $this->success([
                    'token' => $model->createToken('API Token')->plainTextToken,
                ], 'You got registration successfully.!');
            } else {
                DB::rollBack();

                return $this->error(
                'Failed to register customer',
                    500,
                    []
                    );
            }
        } catch (Exception $e) {
            DB::rollBack();
            return $this->error(
                'Server error: ' . $e->getMessage(),
                    500,
                    []
                    );
        }
    }
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|string',
        ]);

        $customer = Customer::where('email', $request->email)->first();

        if (!$customer || !Hash::check($request->password, $customer->password)) {
            return response()->json([
                'message' => 'Invalid credentials.'
            ], 401);
        }

        $token = $customer->createToken('customer-token')->plainTextToken;

        return response()->json([
            'message' => 'Logged in successfully',
            'token' => $token,
            'customer' => new CustomerResource($customer),
        ]);
    }

    public function show(Request $request){
        $customer = $request->user();
    
        if (!$customer) {
            return response()->json(['error' => 'Customer not authenticated'], 401);
        }

        return response()->json([
            'status' => true,
            'message' => 'Data found successfully.',
            'data' => new $this->modelResource($customer)
        ]);
    }

    public function orders(Request $request){
        $customer = $request->user();

        $orders = Order::where('customer_id',$customer->id)->get();

        return response()->json([
            'status' => true,
            'message' => 'Data found successfully.',
            'data' => $orders
        ]);
    }

    public function cancelledOrders(Request $request){
        $customer = $request->user();

        $orders = Order::where('customer_id',$customer->id)->where('order_status','cancelled')->get();

        return response()->json([
            'status' => true,
            'message' => 'Data found successfully.',
            'data' => $orders
        ]);
    }

    public function pendingOrders(Request $request){
        $customer = $request->user();

        $orders = Order::where('customer_id',$customer->id)->where('order_status','pending')->get();

        return response()->json([
            'status' => true,
            'message' => 'Data found successfully.',
            'data' => $orders
        ]);
    }

    public function returnOrders(Request $request){
        $customer = $request->user();

        $orders = Order::where('customer_id',$customer->id)->where('order_status','returned')->get();

        return response()->json([
            'status' => true,
            'message' => 'Data found successfully.',
            'data' => $orders
        ]);
    }

    public function update(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }
    
        try {
            $customer = $request->user();
            $customer->name = $request->name;
            $customer->phone = $request->phone;
            if ($request->hasFile('image')) {
                $uploadPath = 'customers';
                $customer->image = $request->file('image')->store('uploads/'.$uploadPath, 'public');
            }
            $customer->save();
    
            if ($customer) {
                return $this->success([
                    'data' => new CustomerResource($request->user()),
                ], 'You have updated data successfully.!');
            } else {
                return $this->error(
                'Failed to update data',
                    500,
                    []
                    );
            }
        } catch (Exception $e) {
            return $this->error(
                'Server error: ' . $e->getMessage(),
                    500,
                    []
                    );
        }
    }

    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'current_password' => ['required'],
            'new_password' => ['required', 'string', 'min:8', 'confirmed'], // expects `new_password_confirmation`
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = $request->user();

        if (!Hash::check($request->current_password, $user->password)) {
            throw ValidationException::withMessages([
                'current_password' => ['The current password is incorrect.'],
            ]);
        }

        $user->password = Hash::make($request->new_password);
        $user->save();

        return response()->json(['message' => 'Password changed successfully.']);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'message' => 'Logged out successfully'
        ]);
    }
}